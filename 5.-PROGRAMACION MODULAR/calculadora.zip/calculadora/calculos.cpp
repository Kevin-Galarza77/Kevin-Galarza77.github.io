#include "calculos.h"
#include<math.h>
#include<iostream>
#include<iomanip>
using namespace std;
int menu(){
  int op;
  cout<<setw(25)<<"****************"<<endl;
  cout<<setw(25)<<"|**BIENVENIDO**|"<<endl;
  cout<<setw(25)<<"****************"<<endl;
  
  cout<<"\t\t1.-SUMAR"<<endl;
  cout<<"\t\t2.-RESTAR"<<endl;
  cout<<"\t\t3.-MULTIPLICAR"<<endl;
  cout<<"\t\t4.-DIVIDIR"<<endl;
  cout<<"\t\t5.-POTENCIA"<<endl;
  cout<<"\t\t6.-RAIZ CUADRADA"<<endl;
  cout<<"\t\t7.-FACTORIAL"<<endl;
  cout<<"\t\t0.-SALIR"<<endl;
  cout<<"\t\tSelecciona: ";
  cin>>op;
  return  op;
}
void suma(){
  float primero,segundo,respuesta;
  cout<<setw(25)<<"INGRESA EL PRIMER NUMERO: ";
  cin>>primero;
  cout<<setw(25)<<"INGRESA EL SEGUNDO NUMERO: ";
  cin>>segundo;
  respuesta=primero+segundo;
  system("clear");
  cout<<setw(30)<<"LA SUMATORIA ES: ["<<respuesta<<"]"<<endl<<endl;
}
void resta(){
  float primero,segundo,respuesta;
  cout<<setw(25)<<"INGRESA EL PRIMER NUMERO: ";
  cin>>primero;
  cout<<setw(25)<<"INGRESA EL SEGUNDO NUMERO: ";
  cin>>segundo;
  respuesta=primero-segundo;
  system("clear");
  cout<<setw(30)<<"LA RESTA ES: ["<<respuesta<<"]"<<endl<<endl;
}
void multiplicacion(){
  float primero,segundo,respuesta;
  cout<<setw(25)<<"INGRESA EL PRIMER NUMERO: ";
  cin>>primero;
  cout<<setw(25)<<"INGRESA EL SEGUNDO NUMERO: ";
  cin>>segundo;
  respuesta=primero*segundo;
  system("clear");
  cout<<setw(30)<<"SU MULTIPLICACION ES: ["<<respuesta<<"]"<<endl<<endl;
}
void division(){
  float primero,segundo,respuesta;
  cout<<setw(25)<<"INGRESA EL PRIMER NUMERO: ";
  cin>>primero;
  cout<<setw(25)<<"INGRESA EL SEGUNDO NUMERO: ";
  cin>>segundo;
  respuesta=primero/segundo;
  system("clear");
  cout<<setw(30)<<"LA DIVISION ES: ["<<respuesta<<"]"<<endl<<endl;
}
void potencia(){
    float primero,segundo,respuesta;
  cout<<setw(25)<<"INGRESA LA BASE DEL NUMERO: ";
  cin>>primero;
  cout<<setw(25)<<"INGRESA EL EXPONENTE DEL NUMERO: ";
  cin>>segundo;
  respuesta=pow(primero,segundo);
  system("clear");
  cout<<setw(30)<<"LA POTENCIA ES: ["<<respuesta<<"]"<<endl<<endl;
}
void raiz(){
  float primero,segundo,respuesta;
  cout<<setw(25)<<"INGRESA EL NUMERO: ";
  cin>>primero;
  respuesta=sqrt(primero);
  system("clear");
  cout<<setw(30)<<"LA RAIZ CUADRADO ES: ["<<respuesta<<"]"<<endl<<endl;
}
void factorial(){
  int total=1,primero;
  cout<<setw(25)<<"INGRESA EL NUMERO: ";
  cin>>primero;
  for(int i=1;i<primero+1;i++){
    total=total*i;
  }
  system("clear");
  cout<<setw(30)<<"EL FACTORIAL ES: ["<<total<<"]"<<endl<<endl;
}