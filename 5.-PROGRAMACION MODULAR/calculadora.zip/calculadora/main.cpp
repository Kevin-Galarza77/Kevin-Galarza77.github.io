#include <iostream>
#include "calculos.h"
int main() {
  int op;
  do{
  op=menu();
  switch(op){
    case 1:
    {
      suma();
      break;
    }
    case 2:
    {
      resta();
      break;
    }
    case 3:
    {
      multiplicacion();
      break;
    }
    case 4:
    {
      division();
      break;
    }
    case 5:
    {
      potencia();
      break;
    }
    case 6:
    {
      raiz();
      break;
    }
    case 7:
    {
      factorial();
      break;
    }
    case 0:
    {
      system("clear");
      std::cout<<"\t\t\t\t*********\n";
      std::cout<<"\t\t\t\t*GRACIAS*\n";
      std::cout<<"\t\t\t\t*********\n";
      break;
    }
    default:
    {
      system("clear");
      std::cout<<"\t\t\nOPCION INCORRECTA. INTENTA NUEVAMENTE.\n";
      
    }
  }
  }while(op!=0);
}