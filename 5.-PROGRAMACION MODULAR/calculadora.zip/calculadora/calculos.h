
int menu();
void suma();
void resta();
void multiplicacion();
void division();
void potencia();
void raiz();
void factorial();