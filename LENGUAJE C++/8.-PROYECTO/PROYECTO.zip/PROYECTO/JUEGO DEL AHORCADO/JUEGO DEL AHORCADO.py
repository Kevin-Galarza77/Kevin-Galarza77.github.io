import os
import random 
import platform
#importar biblioteca
#mostrar escenas segun avanze el juego
escenas = \
    [
        "\t\t +-------+\n" +
        "\t\t         |\n" +
        "\t\t         |\n" +
        "\t\t         |\n" +
        "\t\t         |\n",
        "\t\t +-------+\n" +
        "\t\t O       |\n" +
        "\t\t         |\n" +
        "\t\t         |\n" +
        "\t\t         |\n",
        "\t\t +-------+\n" +
        "\t\t O       |\n" +
        "\t\t/        |\n" +
        "\t\t         |\n" +
        "\t\t         |\n",
        "\t\t +-------+\n" +
        "\t\t O       |\n" +
        "\t\t/|       |\n" +
        "\t\t         |\n" +
        "\t\t         |\n",
        "\t\t +-------+\n" +
        "\t\t O       |\n" +
        "\t\t/|\      |\n" +
        "\t\t         |\n" +
        "\t\t         |\n",
        "\t\t +-------+\n" +
        "\t\t O       |\n" +
        "\t\t/|\      |\n" +
        "\t\t/        |\n" +
        "\t\t         |\n",
        "\t\t +-------+\n" +
        "\t\t O       |\n" +
        "\t\t/|\      |\n" +
        "\t\t/ \      |\n" +
        "\t\t         |\n", ]
#Palabras que el juego usara al azar
misPalabras = [
    'parangariquitirimicuaro',
    'meticuloso',
    'tripiante',
    'otorrinolaringologia',
    'psicoanalista',
    'geminis',
    'paradox',
    'aspros',
    'shrek',
    'programacion',
    'enredados',
    'kamehamehaa',
    'comibebe',
    'pejelagarto',
    'algoritmo',
    'linus',
    'framework',
    'paralelepipedo',
    'chone',
    'transnacional',
    ]
#seleccionar al azar cualquier palabra
def seleccionarPalabra():
    palabras = random.choice(misPalabras).lower()
    ##palabras = "otorrinolaringologia".lower()
    palabraAux = ""
    c_aux = []
    for c in palabras:
        if random.random() <= 0.9:
            palabraAux = palabraAux + "_"
            c_aux.append(c)
        else:
            palabraAux = palabraAux + c
    return palabras, palabraAux, c_aux
##Proceso del juego
def juego(count, ingresadas, palabras, palabraAux, c_aux):
    print("Complete las letras para adivinar la palabra\n")
    print(escenas[count])
    print(palabraAux)
    if len(escenas) - 1 == count:#En caso de ya perder la partida
        print("\t******************\n"
              "\t     GAME OVER    \n"
              "\t******************\n")
        print("La palabra es correcta: ")
        print(palabras)
        return 0
    a = input("\tIngrese una letra: ").lower()
    if a in ingresadas:
        print("\tLetra ya ingresada")
    ingresadas.append(a)#En caso de repetir la letra ya ingresada
    if a in c_aux:
       #comprobar si todas las letras son correctas
        for i in [i for i, j in enumerate(palabras) if j == a]:
            palabraAux = "".join((palabraAux[:i], a, palabraAux[i + 1:]))
        if palabraAux == palabras:
            print("\t*****************\n"
                  "\t     GANASTE !!!\n"
                  "\t****************\n")
            print("La palabra es: ")
            print(palabras)
            return 0
    else:
      #Intentar denuevo en caso de no ser todas las letras iguales
      if platform.system()=='Windows':
        os.system('cls')
      else:
        os.system('clear')   
      print("** Fallaste intenta de nuevo **")
      count += 1
        #volvemos a iniciar el juego 
    return juego(count, ingresadas, palabras, palabraAux, c_aux)
def inicio():
  #presentar inicio del juego
    while True:
        print('\t\t\t\tAHORCADO \n')
        print("  *** 7 Oportunidades ****\n")
        count = 0
        ingresadas = []
        palabras, palabraAux, c_aux = seleccionarPalabra()
        juego(count, ingresadas, palabras, palabraAux, c_aux)
        a = input("\n¿Desea jugar otra vez? [s/n]: \n").lower()
        if a != "s":
            print("\tFin del juego!")
            break
inicio()